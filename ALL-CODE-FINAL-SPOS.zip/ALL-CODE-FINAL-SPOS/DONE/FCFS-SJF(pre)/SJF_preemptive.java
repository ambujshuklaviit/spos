import java.util.Scanner;

class logicforsjf
{
		int i,j,n,c,st,tot;
		int pid[],at[],bt[],ct[],tat[],wt[],f[],k[];
	
		Scanner scan =new Scanner(System.in);
			
		logicforsjf()
		{
			pid=new int[100];
			at=new int[100];
			bt=new int[100];
			ct=new int[100];
			tat=new int[100];
			wt=new int[100];
			f=new int[100];
			k=new int[100];
			i=j=n=st=tot=c=0;
		}
		
		public void accept()
		{
			System.out.println("Total numbers of proceess");
			n=scan.nextInt();
			
			for(i=0;i<n;i++)
			{
				pid[i]=i+1;				
			}
			System.out.println("Enter arrival time :-");
			for(i=0;i<n;i++)
			{
				at[i]=scan.nextInt();
			}			
			System.out.println("Enter burst  time :-");
			for(i=0;i<n;i++)
			{
				bt[i]=scan.nextInt();
			}			
			for(i=0;i<n;i++)
			{
				k[i]=bt[i];
			}			
			for(i=0;i<n;i++)
			{
				f[i]=0;
			}						
		}

		public void logic()
		{
				while(true)
				{
					int min=999;
					c=n;
					
					for(i=0;i<n;i++)
					{
						if((at[i]<=st)&&(f[i]==0)&&(bt[i]<min))
						{
							min=bt[i];
							c=i;
						}						
					}			
					
					if(c==n)
					{
						st++;
					}
					else
					{
						bt[c]--;
						st++;
						if(bt[c]==0)
						{
							ct[c]=st;
							f[c]=1;
							tot++;
						}						
					}				
					if(tot==n)
					{
						break;
					}
				}			
					
			
			for(i=0;i<n;i++)
			{
				tat[i]=ct[i]-at[i];
				wt[i]=tat[i]-k[i];	
			}			
		}
		public void display()
		{
			System.out.println("table");
			System.out.println("pid\tat\tbt\tCT\twt\ttat");
			
			for(i=0;i<n;i++)
			{
				System.out.println(pid[i]+"\t"+at[i]+"\t"+k[i]+"\t"+ct[i]+"\t"+wt[i]+"\t"+tat[i]);
			}	
		}
		public void avgtime()
		{
			System.out.println("Avg WT :");
			int total_wt,total_tat;
			total_wt=0;
			total_tat=0;
			for(i=0;i<n;i++)
			{
				total_wt=total_wt+wt[i];
			}
			double avgwt=(float)total_wt/n;
			System.out.println(avgwt);
			for(i=0;i<n;i++)
			{
				total_tat=total_tat+tat[i];
			}
			
			double avgtat=(float)total_tat/n;
			System.out.println("AVG TAT:");
			System.out.println(avgtat);
		}
}

public class SJF_preemptive 
{
	public static void main(String args[])
	{
		logicforsjf sjf=new logicforsjf();
	
		sjf.accept();
		sjf.logic();
		sjf.display();
		sjf.avgtime();		
	}
}

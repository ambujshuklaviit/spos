import java.util.Scanner;

class fcfslogic
{
		int i,j,n;
		int pid[],wt[],tat[],bt[];
		Scanner scan=new Scanner(System.in);
		
		fcfslogic()
		{
			i=j=n=0;
			pid=new int[100];
			bt=new int[100];
			tat=new int[100];
			wt=new int[100];
		}
		
		public void accept()
		{
			System.out.println("Enter number of proceeses :\n");
			n=scan.nextInt();
			
			for(i=0;i<n;i++)
			{
				pid[i]=i+1;
			}
			System.out.println("Enter burst time");
			for(i=0;i<n;i++)
			{
				bt[i]=scan.nextInt();
			}			
		}
		
		public void display()
		{
			System.out.println("Table :-");
			System.out.println("pid\t bt\t wt \t tat \t ");
			for(i=0;i<n;i++)
			{
				System.out.println(pid[i]+"\t"+bt[i]+"\t"+wt[i]+"\t"+tat[i]+"\t");				
			}			
		}
		
		public void findall()
		{
			wt[0]=0;
			
			for(i=1;i<n;i++)
			{
				wt[i]=wt[i-1]+bt[i-1];
			}			
			
			for(i=0;i<n;i++)
			{
				tat[i]=wt[i]+bt[i];
			}			
			
		}
		
		public void findavg()
		{
			int total_wt=0;
			int total_tat=0;
			
			for(i=0;i<n;i++)
			{
				total_wt=total_wt+wt[i];
			}
			double avgwt=(float)total_wt/n;			
			System.out.println("avg wt :-");
			System.out.println(avgwt);
			
			for(i=0;i<n;i++)
			{
				total_tat=total_tat+tat[i];
			}
			System.out.println("avg tat :-");
			double avgtat=(float)total_tat/n;		
			System.out.println(avgtat);
		}
}

public class FCFS 
{
	public static void main(String args[])
	{
		fcfslogic fc = new fcfslogic();
		fc.accept();
		fc.findall();
		fc.display();
		fc.findavg();
	}
}

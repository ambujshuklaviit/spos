public class abc
{
	public static void main(String args[])
	{
		int a,b,c;
		a=4;
		b=5;
		c=a+b;
	}
}
